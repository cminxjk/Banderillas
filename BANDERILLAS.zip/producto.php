<section class="content-section bg-secondary text-white text-center" id="Producto">
            <div class="container px-4 px-lg-5">
                <div class="content-section-heading">
                    <h3 class="text-secondary mb-0">Productos</h3>
                    <h2 class="mb-5">Tentador, ¿no?</h2>
                </div>
                <div class="row gx-4 gx-lg-5" id="centrar1">
                    
                   <div class="col-lg-3 col-md-6 mb-5 mb-lg-0">
              <span class="service-icon rounded-circle mx-auto mb-3"><i class=<"material-icons">😋</i></span>
                        <h4><strong>Banderilla</strong></h4>
                        <p class="text-faded mb-0"> Esta compuesto de una salchicha recubierta con una masa de pan de maíz y que posteriormente se fríe en aceite muy caliente</p>
                    </div>
                  
                    <div class="col-lg-3 col-md-6 mb-5 mb-md-0">
                        
                            <span class="service-icon rounded-circle mx-auto mb-3"><i class=<"material-icons">💗</i></span>
                   
                        <h4 ><strong>Cuki Corazon</strong></h4>
                        <p class="text-faded mb-0">
                            Es galleta molida, rellena de arequipe, cubierta con un poco de chocolate 
                           
                            
                        </p> 
                    
                  </div>
                </div>
            </div>
        </section>
        <!-- Callout-->
      
        <!-- Portfolio-->
        

