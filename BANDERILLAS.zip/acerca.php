<section class="content-section bg-light" id="Acerca">
            <div class="container px-4 px-lg-5 text-center">
                <div class="row gx-4 gx-lg-5 justify-content-center">
                    <div class="col-lg-10">
            
                          
                        <h4><br> !Bienvenidos a nuestro emprendimiento¡</br></h4></i>
                        </div>
                        <div class="col-lg-3  mb-5 mb-md-0">
                        
                          <h4><strong>Hecho por:</strong></h4>
                          <p class="lead mb-5">
                        
                       
                          <br> Maikel Fornerino
                          <br> Tatiana Jaramillo
                          <br> Camila Morales  
                          <br> Keren Restrepo
                        </p>
                          <p class="text-black mb-0 text-justify">
                           <p class="lead mb-5">
                             <br><excel src="cálculo.xlsx">
                        </p>
                        <a class="btn btn-danger btn-xl" href="#Productos">Productos</a>
                          
                    
                       
                     
          </div>
      </div>
</section>