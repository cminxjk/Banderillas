<a class="menu-toggle rounded" href="#"><i class="fas fa-bars"></i></a>
        <nav id="sidebar-wrapper">
            <ul class="sidebar-nav">
                <li class="sidebar-brand"><a href="#page-top">Explora</a></li>
                <li class="sidebar-nav-item"><a href="#Acerca">Acerca</a></li>
                <li class="sidebar-nav-item"><a href="#Producto">Productos</a></li>
               <li class="sidebar-nav-item"><a href="#proyecto">Proyecto</a></li>
                <li class="sidebar-nav-item"><a href="#contactos">Contacto</a></li>
              <li class="sidebar-nav-item"><a href="excel/calculo.xlsx">Costos</a></li>
                   
            </ul>
        </nav>